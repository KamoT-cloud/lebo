document.getElementById('imgInp').onchange = function (evt) {
    const [file] = this.files;
    if (file) {
      const preview = document.getElementById('img-upload');
      preview.src = URL.createObjectURL(file);
      preview.style.display = 'block';
    }
  };
  