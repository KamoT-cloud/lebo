from flask import Flask, render_template, request, redirect, url_for
import os
from werkzeug.utils import secure_filename

# Flask setup
app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Make sure the uploads folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploaded', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part in the request.'
    
    file = request.files['file']
    if file.filename == '':
        return 'No file selected.'
    
    # Save the uploaded image
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    return render_template('uploaded.html', img_path=filepath)
    
if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)